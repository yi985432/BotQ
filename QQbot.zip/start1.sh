sudo apt update
sudo apt upgrade
sudo apt install openjdk-11-jdk python3 pip
sudo pip install graia-application-mirai
sudo ./mcl
sudo sleep 20
sudo python3 bot.py
