import requests, json, os, codecs

#初始化
def rinit():
 if os.path.exists('data')==False:
   os.makedirs('data')      
    
 if os.path.exists('data/Group.txt')==False:
   os.mknod('data/Group.txt')
    
#增加Robot管理的群
def addgp(gid):
    gid=str (gid)
    gid=gid.split()
    gid=" ".join(gid)    
    data=open('data/Group.txt','r+')
    listening=data.read().replace("\n"," ").split()
    if gid in listening:
     return 225
    else:
     data.write("\n"+gid+"\n")
     data.close() 
     return 0 

#减少Robot管理的群
def delgp(gid):
    gid=str (gid)
    gid=gid.split()
    gid=" ".join(gid)
    data=open('data/Group.txt','r+')
    read=data.read().replace("\n"," ")
    if gid in read:       
     res=read.split()
     res.remove(gid)  
     res=" ".join(res)
     data.seek(0)
     data.truncate()
     data.write("\n"+res+"\n")
     data.close()
     return 0
    else:
     return 404  

#查看Robot所有管理的群
def lookgp():
   data=open('data/Group.txt','r')
   lis=data.read().replace("\n"," ").split()   
   data.close()
   return lis
