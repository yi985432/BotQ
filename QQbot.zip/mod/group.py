import requests, json, os, codecs

#初始化
def ginit(gid):
 #默认敏感词
# Forbidden="傻逼 你妈炸了 TM nmsl 你没事了 你没吗 你没马 cnm 擦你妈 你妈逼"
 id=(str (gid))
 
 if os.path.exists('data')==False:
    os.makedirs('data')      
 
 if os.path.exists('data/{}'.format(id))==False:
    os.makedirs('data/{}'.format(id))  
    
 if os.path.exists('data/{}/Permission.txt'.format(id))==False:
    os.mknod('data/{}/Permission.txt'.format(id))

 if os.path.exists('data/{}/Forbidden.txt'.format(id))==False:
    os.mknod('data/{}/Forbidden.txt'.format(id))
#    wite=open('data/{}/Forbidden.txt'.format(id),'r+')
#    wite.write(Forbidden)#写入默认敏感词
#    wite.close()
    
 if os.path.exists('data/{}/OF.txt'.format(id))==False:
    os.mknod('data/{}/OF.txt'.format(id))
    wite=open('data/{}/OF.txt'.format(id),'r+')
    wite.write('1')#默认1为机器人开机状态
    wite.close()


#增加Robot特定管理员
def addgm(gid,qid):
    gid=str (gid)
    qid=str (qid)    
    data=open('data/{}/Permission.txt'.format(gid),'r+')
    listening=data.read().replace("\n"," ").split()    
    if qid in listening:
     return 250
    else:
     data.write("\n"+qid+"\n")
     data.close() 
     return 0 
             
#减少Robot特定管理员
def delgm(gid,qid):
    gid=str (gid)
    qid=str (qid)  
    data=open('data/{}/Permission.txt'.format(gid),'r+')
    read=data.read().replace("\n"," ")
    if qid in read:       
     res=read.split()
     res.remove(qid)  
     res=" ".join(res)
     data.seek(0)
     data.truncate()
     data.write("\n"+res+"\n")
     data.close()
     return 0
    else:
     return 243  
     
           
#查看Robot所有管理员
def lookgm(gid):
   id=str (gid)
   data=open('data/{}/Permission.txt'.format(id),'r')
   lis=data.read().replace("\n"," ").split()   
   data.close()
   return lis
   
   
#Robot开
def on(gid):
   id=str (gid)
   of=open('data/{}/OF.txt'.format(id),'r+')
   read=of.read()
   if "1" in read:
    return "Robot已经为开机状态"
   else:
    of.seek(0)
    of.truncate()
    of.write("1")
    of.close  
    
        
#Robot关
def off(gid):
   id=str (gid)
   of=open('data/{}/OF.txt'.format(id),'r+')
   read=of.read()
   if "0" in read:
    return "Robot已经为关机状态"
   else:
    of.seek(0)
    of.truncate()
    of.write("0")
    of.close    

#Robot开关判断(返回0为关，返回1为开)
def of(gid):
   id=str (gid)
   of=open('data/{}/OF.txt'.format(id),'r+')
   read=of.read()
   if read=="0":
    return 0
    
   if read=="1":
    return 1
    
#消息链转字典合并
def dic(message):
 try:
     message=message
     dic1=message.dict()['__root__'][0]
     dic2=message.dict()['__root__'][1]
     dic3=message.dict()['__root__'][2]
 except IndexError:
     dic=dict(dic1,**dic2)
 else:   
     dic2['type1'] = dic2.pop('type')   
     dic=dict(dic1,**dic2,**dic3)

 return dic
 
#色图函数
def setu():
     url="https://api.lolicon.app/setu/?apikey=088438066071c0979c7016"
     res=requests.get(url)
     dic=json.loads(res.text)
     url=dic['data'][0]['url']
     return url

#默认敏感词
def Forbidden():
   data=open('mod/默认敏感词.txt','r')
   lis=data.read().replace("\n"," ").split()   
   data.close()
   return lis

#增加敏感词
#def addForbidden(gid,string):
#    gid=str (gid)
#    string=str (string)    
#    data=open('data/{}/Forbidden.txt'.format(gid),'r+')
#    listening=data.read().replace("\n"," ").split()    
#    if string in listening:
#     return 100
#    else:
#     data.write("\n"+string+"\n")
#     data.close() 
#     return 0 
#模糊敏感词
#确定敏感词