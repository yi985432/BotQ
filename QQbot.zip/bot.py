#!/usr/bin/python3
"""
1.声明：Robot制作出来的目的只是为了学习交流及方便群友，请勿用于其他用途！
2.Robot使用Graia framework和mirai(mirai-api-http)实现，需要Python3.7+.
3.如果你还没有安装Graia framework，你可以使用"pip install graia-application-mirai"来安装.
4.Graia framework官方文档：https://graia-document.vercel.app/                  
"""
#引入
import json, requests, random, re, os, time, datetime
import asyncio
from graia.application.event.mirai import NewFriendRequestEvent, BotInvitedJoinGroupRequestEvent, NudgeEvent
from graia.broadcast import Broadcast
from graia.application import GraiaMiraiApplication, Session
from graia.application.message.chain import MessageChain
from graia.application.message.elements.internal import Plain, Source, At
from graia.application.friend import Friend
from graia.application.group import Group, Member
from graia.application import Image
from graia.broadcast.interrupt import InterruptControl
from graia.broadcast.interrupt.waiter import Waiter
from graia.application.event.messages import GroupMessage, FriendMessage
from mod.group import setu, ginit, addgm, delgm, off, of, on, dic, lookgm, Forbidden
from mod.friend import addgp, delgp, rinit, lookgp
#配置：
#机器人QQ号
qq=3380874573
#mirai-api-http的authKey
authKey="12345678"
#mirai-api-http的服务运行地址
host="http://localhost:8080"
#
loop = asyncio.get_event_loop()
import time
bcc = Broadcast(loop=loop)
app = GraiaMiraiApplication(
    broadcast=bcc,
    connect_info=Session(
        host=host, # 填入 httpapi 服务运行的地址
        authKey=authKey, # 填入 authKey
        account=qq, # 你的机器人的 qq 号
        websocket=True # Graia 已经可以根据所配置的消息接收的方式来保证消息接收部分的正常运作.
    )
)
inc = InterruptControl(bcc)


#Robot名字
NAME="小娜"
#Robot主人
Main=3586563103#主人QQ号，只能为一个
#Robot被关机随机回复
offbot=[NAME+"已关机～\n~_~",NAME+"先走了，灰灰～\n |_・)","再见"]
#Robot被开机随机回复
onbot=[NAME+"回来了哦～\n╭(￣▽￣)╮","我，"+NAME+"，终于回来了！！\n(~￣△￣)~"]
#模糊关键字
hao=["色图","来张色图","随机色图","色图来","lsp","LSP","涩图","我要色图","随机涩图","setu"]
baba=["叫爸爸","叫声爸爸","我是你爸爸"]
#随机回复
sehf=["LSP你的涩图正在路上，请稍后……","LSP给你一记ď"]
me=["呼叫"+NAME+"有什么事吗？~\n\(≧▽≦)/~",NAME+"在呢~有什么事吗？^ω^","这里是"+NAME+" (づ ●─● )づ"]
#入群欢迎
welcome=["欢迎~","欢迎进群~","欢迎进群呐~"]
#退群响应
Retreat=["有人跑路了~","群里又少了一个人…"]
#当前时间
nowtime=["当前时间","报个时","时间","/当前时间","/报个时","/时间"]
#管理员菜单
gmmenu="\
管理员菜单：\n\
1.Robot开机：\n\
/开机\n\
2.Robot关机：\n\
/关机\n\
3.新增Robot管理员：\n\
@Robot /增加管理员 @增加对象\n\
4.删除Robot管理员：\n\
@Robot /删除管理员 @删除对象\n\
5.查看Robot管理员：\n\
/查看Robot管理员\n\
6.全体禁言[管理员]：\n\
/全体禁言\n\
7.全体解禁[管理员]：\n\
/全体解禁\n\
8.禁言指定成员[管理员]：\n\
/禁言 @禁言对象 时间[S]\n\
9.解禁指定成员[管理员]：\n\
/解禁 @解禁对象\n\
10.移出群成员[管理员]：\n\
/移出 @移出对象\
"
#主人菜单
Mainmenu="\
主人菜单：\n\
1.查看Robot管理的群：\n\
/查看管理的群\n\
2.增加Robot管理的群：\n\
/增加群 群号\n\
3.减少Robot管理的群：\n\
/减少群 群号\
"
main=str (Main).split()#int转list
#群消息事件 
@bcc.receiver("GroupMessage")
async def GroupMessage(member: Member, message: MessageChain, app: GraiaMiraiApplication, group: Group, source: Source):
#变量实现
  gop=lookgp()#群号范围
  if str (group.id) in gop: #判断监听群号是否在范围内 
     gid=(group.id)#群ID
     ginit(gid)#初始化
     dicts=dic(message)#实例化字典消息链 
     NO=Forbidden()#默认敏感词 类型：List    
     messages = message.asDisplay()
     sourceid=source.id

     try:
      dicts['text']#返回文字内容
     except KeyError:
      msg=""
     else:
      msg=dicts['text']
           
     strdic=str (message)#转为字符串后的消息链
     strqq=str (qq)#转为字符串后的QQ号
     GroupGM=lookgm(gid)#获取所有管理员
     qid=str (member.id)#当前说话人的ID(字符串)
     NowTime=str (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))#当前时间
     listdict=(message.dict()['__root__'])#字典元组消息链，后面加[1]可以提取字典，[1]随消息链变化而变化，可以为[1]、[2]、[3]……
#开机和关机(需要管理员和主人的权限)
    #关机
     if msg in ["/关机"]:
#      if "At" in strdic:
#       if strqq in strdic:
          if qid in GroupGM+main:
            if of(gid)==0:
             await app.sendGroupMessage(group, MessageChain.create([
              Plain("{}已是关机状态~\n ⊙ω⊙".format(NAME))
                 ]))               
            else:          
             off(gid)
             await app.sendGroupMessage(group, MessageChain.create([
              Plain(random.choice(offbot))
                 ]))
                 
          else:
             await app.sendGroupMessage(group, MessageChain.create([
              Plain("ERROR：PermissionError\n抱歉，你的权限不足\n╮(╯_╰)╭")
                 ]))
         
     #开机
     if msg in ["/开机"]:
#      if "At" in strdic:
#       if strqq in strdic:
         if qid in GroupGM+main:
          if of(gid)==1:
             await app.sendGroupMessage(group, MessageChain.create([
              Plain("{}已是开机状态~\n( ∩՞ټ՞∩) 喵～～".format(NAME))
                 ]))                      
          else:
             on(gid)
             await app.sendGroupMessage(group, MessageChain.create([
               Plain(random.choice(onbot))
                 ]))        
         else:
             await app.sendGroupMessage(group, MessageChain.create([
              Plain("ERROR：PermissionError\n抱歉，你的权限不足\n╮（﹀＿﹀）╭")
                 ]))
      
#Robot开关机判断
#判断为开机
     if of(gid)==1:
 #无需管理员权限可以触发的函数
     #敏感词检测
       for name in NO:
         if name in messages:
             await app.revokeMessage(sourceid)
             await app.sendGroupMessage(group, MessageChain.create([
              Plain("检测到敏感词，已自动撤回。")
                 ]))
     #当前时间
       if msg in nowtime:
         await app.sendGroupMessage(group, MessageChain.create([
           Plain("当前时间为：\n"+NowTime)
           ]))     
       
     #涩图
       if msg in hao :
         await app.sendGroupMessage(group, MessageChain.create([
           At(member.id), Plain("\n"+random.choice(sehf))]))     
         await app.sendGroupMessage(group, MessageChain.create([
           Image(url=setu())#.asFlash()
             ]))
       if msg in ["不够色"]:
         await app.sendGroupMessage(group, MessageChain.create([
           Plain("那你来发")]))     
                  
     #有人吗？
       if msg in ["有人吗？","有人吗","群里有没有人？","群里有人吗？"]:
         await app.sendGroupMessage(group, MessageChain.create([
          Plain("没有呢~")
            ]))
       elif msg in ["有","有人","这不是有人吗？"]:
         await app.sendGroupMessage(group, MessageChain.create([
          Plain("有什么？")
            ]))
       
     #叫爸爸
       if msg in baba :
        if qid in GroupGM+main:
         await app.sendGroupMessage(group, MessageChain.create([
          Plain("爸爸")
           ]))
        elif msg in baba :
          await app.sendGroupMessage(group, MessageChain.create([
           Plain("你叫什么？")
           ]))
                
       if msg in ["爸爸"] :
        await app.sendGroupMessage(group, MessageChain.create([
        Plain("诶！儿子乖~")
        ]))   
             
       if msg in ["儿子"]:
        if qid in GroupGM+main:
         await app.sendGroupMessage(group, MessageChain.create([
          Plain("爸爸")
           ]))        
        elif msg in ["儿子"]:
          await app.sendGroupMessage(group, MessageChain.create([
           Plain("我是你爸爸")
             ]))
       
       #查看Robot管理员
       if msg in ["/查看Robot管理员"]:
          await app.sendGroupMessage(group, MessageChain.create([
           Plain("当前群Robot管理员：\n{}".format(lookgm(gid)))
             ]))
        
         
    #被@才响应的  
       if "At" in strdic:
         if strqq in strdic:
         #当机器人被不带文本@时
             if msg in [" ",""]:
              await app.sendGroupMessage(group, MessageChain.create([
               Plain(random.choice(me))
                 ]))
            
 #需要管理员(主人)权限才能触发的函数
       if qid in GroupGM+main:  
     #管理员菜单
        if msg in ["/菜单"]:
#          if qid in GroupGM+Main:
              await app.sendGroupMessage(group, MessageChain.create([
               Plain(gmmenu)
                 ]))
     #全体禁言
        if msg in ["/全体禁言"]:
          try:
            await app.muteAll(group)
          except PermissionError:
            await app.sendGroupMessage(group, MessageChain.create([
             Plain("错误：PermissionError\nRobot在当前群没有管理员权限。")
               ]))
             
     #全体解禁  
        if msg in ["/全体解禁"]:
          try:
            await app.unmuteAll(group)
          except PermissionError:
            await app.sendGroupMessage(group, MessageChain.create([
             Plain("错误：PermissionError\nRobot在当前群没有管理员权限。")
               ]))
            
     #禁言指定群成员
        if msg in ["/禁言 ", "/禁言"]:            
             try:
               listdict[3]['text']
             except IndexError:
              await app.sendGroupMessage(group, MessageChain.create([
               Plain("使用：\n/禁言 @禁言对象 时间[S]")
                 ]))
             else: 
              date=int (listdict[3]['text'])
              name=int (listdict[2]['target'])
              try:
               await app.mute(group, name, date)
              except PermissionError:
               await app.sendGroupMessage(group, MessageChain.create([
                Plain("错误：PermissionError\nRobot在当前群没有管理员权限。")
                 ]))   
                             
              
      #解禁指定群成员        
        if msg in ["/解禁","/解禁 "]:
              try:
                listdict[2]['target']    
              except IndexError:
                await app.sendGroupMessage(group, MessageChain.create([
                 Plain("使用：\n/解禁 @解禁对象")
                   ]))
              else: 
                 name=int (listdict[2]['target'])
                 try:
                  await app.unmute(group, name)
                 except PermissionError:
                  await app.sendGroupMessage(group, MessageChain.create([
                   Plain("错误：PermissionError\nRobot在当前群没有管理员权限。")
                   ]))   
   
      #移出指定群成员                                                   
        if msg in ["/移出","/移出 "]:
              try:
                listdict[2]['target']    
              except IndexError:
                await app.sendGroupMessage(group, MessageChain.create([
                 Plain("使用：\n/移出 @移出对象")
                   ]))
              else: 
                 name=int (listdict[2]['target'])                
                 try:
                  await app.kick(group, name)
                  await app.sendGroupMessage(group, MessageChain.create([
                   Plain("已移出群成员：{}".format(name))
                   ]))                                                                 
                 except PermissionError:
                  await app.sendGroupMessage(group, MessageChain.create([
                   Plain("错误：PermissionError\nRobot在当前群没有管理员权限。")
                   ]))           
          
                                  
   #被@才响应的
        if "At" in strdic:
         if strqq in strdic:
     #增加管理员
          if msg in ["/增加管理员 "," /增加管理员 "," /增加管理员","/增加管理员"]:
#           if "At" in strdic:
#            if strqq in strdic:
#             if qid in GroupGM+Main:
             try:
               listdict[3]['target']
             except IndexError:
              await app.sendGroupMessage(group, MessageChain.create([
               Plain("使用：\n@Robot /增加管理员 @增加对象")
                 ]))
             else: 
              add=str (listdict[3]['target'])
              res=addgm(gid,add)
              if res==0:
               await app.sendGroupMessage(group, MessageChain.create([
                Plain("新增Robot管理员："+add)
                 ]))
              elif res==250:
               await app.sendGroupMessage(group, MessageChain.create([
                Plain("ERROR：已经增加了。")
                 ]))             
                              
#           else:
#             await app.sendGroupMessage(group, MessageChain.create([
#              Plain("ERROR：UNPERMISSION\n抱歉，你的权限不足")
#                 ]))

     #删除管理员
          if msg in ["/删除管理员 "," /删除管理员 "," /删除管理员","/删除管理员"]:
#           if "At" in strdic:
#          if strqq in strdic:
#             if qid in GroupGM+Main:
            try:
              listdict[3]['target']
            except IndexError:
              await app.sendGroupMessage(group, MessageChain.create([
               Plain("使用：\n@Robot /删除管理员 @删除对象")
                 ]))
            else: 
             delg=str (listdict[3]['target'])
             res=delgm(gid,delg)
             if res==0:
              await app.sendGroupMessage(group, MessageChain.create([
               Plain("删除Robot管理员："+delg)
                 ]))
             elif res==243:
              await app.sendGroupMessage(group, MessageChain.create([
               Plain("ERROR：已经删除了或没有增加。")
                 ]))             
                              
#           else:
#             await app.sendGroupMessage(group, MessageChain.create([
#              Plain("ERROR：UNPERMISSION\n抱歉，你的权限不足")
#                 ]))
       #Robot退群 
          if msg in ["走了","Boom"]:
           if qid in main:
              time.sleep(5)
              await app.sendGroupMessage(group, MessageChain.create([
               Plain("{}自爆程序已启动！".format(NAME))
                 ]))
              time.sleep(5)
              await app.sendGroupMessage(group, MessageChain.create([
               Plain("{}5秒后将爆炸！".format(NAME))
                 ]))
              time.sleep(5)
              await app.sendGroupMessage(group, MessageChain.create([
               Plain("Booom……".format(NAME))
                 ]))
              time.sleep(3)                 
              await app.quit(group)                  
             
#判断为关机
     if of(gid)==0:
       if  "At" in strdic:
        if strqq in strdic:
#         if not msg in  ["关机"," 关机"]:        
          await app.sendGroupMessage(group, MessageChain.create([
              Plain("肥肠抱歉~当前{}处于关机状态，快叫Robot管理员开机吧~".format(NAME))
                 ]))                			       
		
#新成员入群事件
@bcc.receiver("MemberJoinEvent")
async def MemberJoinEvent(app: GraiaMiraiApplication, group: Group):
  gop=lookgp()#群号范围  
  if str (group.id) in gop: #判断监听群号是否在范围内 
       if of(group.id)==1: #判断开关机
          await app.sendGroupMessage(group, MessageChain.create([
              Plain(random.choice(welcome))
                 ]))      
                           			      
#群成员退群事件
@bcc.receiver("MemberLeaveEventQuit")
async def MemberJoinEvent(app: GraiaMiraiApplication, group: Group, member: Member):
  gop=lookgp()#群号范围
  if str (group.id) in gop: #判断监听群号是否在范围内
       if of(group.id)==1: #判断开关机
          await app.sendGroupMessage(group, MessageChain.create([
              Plain(random.choice(Retreat)),Plain("\n这个人是"+member.name+"({})".format(member.id))
                 ]))      

#Robot加入群组
@bcc.receiver("BotJoinGroupEvent")
async def BotJoinGroupEvent(app: GraiaMiraiApplication, group: Group):
  gop=lookgp()#群号范围
  if str (group.id) in gop: #判断监听群号是否在范围内 
              await app.sendGroupMessage(group, MessageChain.create([
               Plain("Hello！\nMy name is {}！\n我是一个不正经的Robot\n喜欢干点不正经的……\n查看功能可以发送[菜单]".format(NAME))
                 ]))   


@bcc.receiver("FriendMessage")
async def msg(app: GraiaMiraiApplication, event: FriendMessage):
         return event   

#机器人被加好友事件
@bcc.receiver("NewFriendRequestEvent")
async def NewFriendRequestEvent(app: GraiaMiraiApplication, event: NewFriendRequestEvent):
          fdid=event.supplicant# 发起加好友请求的用户的 ID
          fdgroup=event.sourceGroup# 对方可能是从某个群发起对账号的请求的, mirai 可以解析对方从哪个群发起的请求.
          fdmsg=event.message# 对方发起请求时填写的描述
#          if fdmsg in ["我同意"]:
#          await event.accept()
#          else:
#          await event.reject()
#          if fdid == Main:
#             await event.accept()
#          await app.sendFriendMessage(Main, MessageChain.create([
#           Plain("主人~\n有人要加{}为好友\nQQ号：{}\n请求的群号：{}\n好友请求描述：'{}'\n回复'/同意'表示通过\n回复'/不同意'表示不通过\n回复'/永不同意'表示拒绝并不再通过".format(NAME, fdid, fdgroup, fdmsg))
#           ])) 

#好友消息事件
@bcc.receiver("FriendMessage")
async def friendmsg(message: MessageChain, friend: Friend, app: GraiaMiraiApplication):
 rinit()#初始化
 msg = message.asDisplay()
 NowTime=str (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))#当前时间 
 #所有好友可用
     #涩图
 if msg in hao :
         await app.sendFriendMessage(friend, MessageChain.create([
           Plain(random.choice(sehf))]))     
         await app.sendFriendMessage(friend, MessageChain.create([
           Image(url=setu())#.asFlash()
             ]))
 if msg in ["不够色"]:
         await app.sendFriendMessage(friend, MessageChain.create([
           Plain("那你来发")]))      

     #叫爸爸
 if msg in baba :
   if friend.id == Main:
    await app.sendFriendMessage(friend, MessageChain.create([
      Plain("爸爸")
       ]))
   elif msg in baba :
          await app.sendFriendMessage(friend, MessageChain.create([
           Plain("你叫什么？")
           ]))
                
 if msg in ["爸爸"] :
        await app.sendFriendMessage(friend, MessageChain.create([
        Plain("诶！儿子乖~")
        ]))   
             
 if msg in ["儿子"]:
    if friend.id == Main:
         await app.sendFriendMessage(friend, MessageChain.create([
          Plain("爸爸")
           ]))        
    elif msg in ["儿子"]:
          await app.sendFriendMessage(friend, MessageChain.create([
           Plain("我是你爸爸")
             ]))
  #时间
 if msg in nowtime:
         await app.sendFriendMessage(friend, MessageChain.create([
           Plain("当前时间为：\n"+NowTime)
           ]))     
   
 #主人可用
 #判断是不是主人
 if friend.id == Main:
   #菜单
   if msg in ["/菜单"]:
        await app.sendFriendMessage(Main, MessageChain.create([
        Plain(Mainmenu)
          ]))             
   #增加管理的群  
   if "/增加群" in msg:
       data=msg[4:]    
       res=addgp(data)
       if res==0:
        await app.sendFriendMessage(Main, MessageChain.create([
        Plain("已增加管理的群：{}".format(data))
          ]))
       if res==225:
        await app.sendFriendMessage(Main, MessageChain.create([
        Plain("已经增加了")
          ]))
    #减少管理的群                
   if "/减少群" in msg:
       data=msg[4:]    
       res=delgp(data)
       if res==0:
        await app.sendFriendMessage(Main, MessageChain.create([
        Plain("已减少管理的群：{}".format(data))
          ]))             
       if res==404:
        await app.sendFriendMessage(Main, MessageChain.create([
        Plain("已经减少了或者没有增加")
          ]))             
    #查看管理的群                     
   if msg in ["/查看管理的群"]:
        res=lookgp()
        await app.sendFriendMessage(Main, MessageChain.create([
        Plain("当前Robot管理的群：{}".format(res))
          ]))             

#Robot被截事件
@bcc.receiver("NudgeEvent")
async def BotNudgeEvent(app: GraiaMiraiApplication, event: NudgeEvent):
  group_id=event.dict()["group_id"]#群ID
  friend_id=event.dict()["friend_id"]#好友ID
  #好友被截
  if friend_id != None:
   await app.sendFriendMessage(friend_id, MessageChain.create([
      Plain("请不要截{} >_<".format(NAME))
      ]))     
  #群被截
  gop=lookgp()#群号范围
  if str (group_id) in gop: #判断监听群号是否在范围内 
       if of(group_id)==1: #判断开关机
              await app.sendGroupMessage(group_id, MessageChain.create([
               Plain("请不要截{} >_<".format(NAME))
                 ]))   
   
#程序固定尾
app.launch_blocking()
