apt update
apt upgrade
apt install openjdk-11-jdk python3 pip
pip install graia-application-mirai
nohup ./mcl >/dev/null 2>&1 &
sleep 20
nohup python3 bot.py >/dev/null 2>&1 &
