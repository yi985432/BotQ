sudo apt update
sudo apt upgrade
sudo apt install openjdk-11-jdk python3 pip
sudo pip install graia-application-mirai
sudo nohup ./mcl >/dev/null 2>&1 &
sudo sleep 20
sudo nohup python3 bot.py >/dev/null 2>&1 &
